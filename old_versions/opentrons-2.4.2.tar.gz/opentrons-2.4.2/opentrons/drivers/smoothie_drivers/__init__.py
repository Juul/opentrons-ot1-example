class SmoothieDriver(object):

    def __init__(self):
        pass


class VirtualSmoothie(object):

    def __init__(self):
        pass
